#include "Armor.h"

#include <iostream>
#include <string>

using namespace std;

Armor::Armor(string nameIn, float extraHealthIn, int slotIn) : Equipable(nameIn)
{
	extraHealth = extraHealthIn;
	slot = slotIn;

}

float Armor::getExtraHealth()
{
	return extraHealth;
}

int Armor::getSlot()
{
	return slot;
}

void Armor::equip()
{
	// Item* i = this;
	// cout << "my name is: " << i->getName() << endl;

	cout << "my name is: " << this->getName() << endl;
}

void Armor::unequip()
{

}