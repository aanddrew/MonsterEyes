#ifndef GAME_H
#define GAME_H

#include "Player.h"
#include "Zone.h"

class Game
{
private:
	Player p;
	Zone[112] zones;

	int currentZone;
public:
	void generateZones();

	void changeZone();

	void playGame();
};
#endif