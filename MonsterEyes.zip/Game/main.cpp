#include <iostream>

#include "Game.h"
/*
All *code* in this project is original and written by me, Andrew Weller (andrewweller.cs@gmail.com)

I did borrow the text file "first-names.txt" from this github link:
https://github.com/dominictarr/random-name/blob/master/first-names.txt

*/

using namespace std;

int main()
{
	Game g;

	g.playGame();

	return 0;
}